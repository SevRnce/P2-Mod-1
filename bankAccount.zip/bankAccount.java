
/**
 * 
 */
/**
 * 
 * 
 */
public class bankAccount {

	private String firstName;
	private String lastName;
	private int accountID;
	private Double balance;
	
	public bankAccount() {
		this.balance = 0.0;
	}
	
	
	public bankAccount(String fName, String lName, int ID, Double bal) {
		this.firstName = fName;
		this.lastName = lName;
		this.accountID = ID;
		this.balance = bal;
	}
	
	public void setFName(String fName) {
		this.firstName = fName;
	}
	public void setLName(String lName) {
		this.lastName = lName;
	}
	public void setID(int sID) {
		this.accountID = sID;
	}
	public void setBalance(Double sBal) {
		this.balance = sBal;
	}
	
	public String getFName() {
		return firstName;
	}
	public String getLName() {
		return lastName;
	}
	public int getID() {
		return accountID;
	}
	public Double getBalance() {
		return balance;
	}
	
	public void deposit(double total) {
		balance += total;
	}
	
	public void withdraw(double total) {
		balance -= total;
	}
	
	public void summary() {
		System.out.println("\nAccount Summary");
		System.out.println("Name: " + lastName + "," + firstName);
		System.out.println("ID: " + accountID);
		System.out.println("Balance: " + balance);
	}
}