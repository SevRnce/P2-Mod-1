public class CheckingAccount extends bankAccount {

	private double interest;
	private double overdraft = 30.00;
	
	public CheckingAccount(String fName, String lName, int ID, double bal, double interest) {
		super(fName, lName, ID, bal);
		this.interest = interest;
	}
	
	public void exWithdraw(double total) {
		this.withdraw(total);
		if (getBalance() < 0) {
			System.out.println("\nInsufficient funds, $" + overdraft + " fee applied.");
			this.withdraw(overdraft);
		}
	}
	
	public void accountInt() {
		summary();
		System.out.println("Interest Rate: " + String.format("%.2f",interest) + "%");
	
	}
}