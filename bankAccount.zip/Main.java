public class Main{
	public static void main(String[] args) {
		CheckingAccount checking = new CheckingAccount("Ray", "Chill", 123456, 10000, 1.2);
		
		checking.accountInt();
		checking.exWithdraw(7000);
		checking.accountInt();
		checking.deposit(500);
		checking.accountInt();
		checking.exWithdraw(8000);
		checking.accountInt();
	}
}